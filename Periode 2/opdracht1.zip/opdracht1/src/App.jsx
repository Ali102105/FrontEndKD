import './css/App.css'
import './css/index.css'
import Nav from './component/Nav.jsx'
import Middle from './component/Middle.jsx'

function App() {

  return (
    <>
    <Nav/>
    <Middle/>
    </>
  );
}

export default App
